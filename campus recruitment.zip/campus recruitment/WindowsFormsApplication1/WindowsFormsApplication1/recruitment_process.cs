﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class recruitment_process : Form
    {
     
        public recruitment_process()
        {
            InitializeComponent();
        }



        public void recruitment_process_Load(object sender, EventArgs e)
        {
            loadcombo();
            show_class_detail();
        }
        private void loadcombo()
        {

            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select [company name] as Name,[company id] as Code from comp_details";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud1");

            comboBox1.DataSource = Sds.Tables[0];
            comboBox1.DisplayMember = Sds.Tables[0].Columns["Name"].ToString();
            comboBox1.ValueMember = Sds.Tables[0].Columns["Code"].ToString();
          
            //dataGridView1.DataSource = Sds.Tables["stud"];

        }

        private void recruitment_process_Load_1(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.ReadOnly = true;
            loadcombo();
            show_class_detail();
        }


        private void show_class_detail()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select  comp_details.[company name] as Name,[company id] as Code,recruitment.[company name],[no. of rounds],[round 1],[round 2],[round 3],[required students] from comp_details,recruitment where comp_details.[company name]=recruitment.[company name]";
            //string s1 = "select Dept_name from dept_master where Dept_id=comboBox1.SelectedValue.ToString()";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud");
            comboBox1.DataSource = Sds.Tables[0];
            comboBox1.DisplayMember = Sds.Tables[0].Columns["Name"].ToString();
            comboBox1.ValueMember = Sds.Tables[0].Columns["Code"].ToString();
          
            dataGridView1.DataSource = Sds.Tables["stud"];

        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into [recruitment] values([company name],[no. of rounds],[round 1],[round 2],[round 3],[required students])('" + comboBox1.SelectedItem + "','" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "',"+numericUpDown1.Value + ")", con);
                cmd.ExecuteNonQuery();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
     

        /*private void button2_Click(object sender, EventArgs e)
        {
            AddNewTextBox();      
        }*/


       /* public System.Windows.Forms.TextBox AddNewTextBox()
        {
           

           System.Windows.Forms.TextBox txt = new System.Windows.Forms.TextBox();    
                this.Controls.Add(txt); 
                return txt;*/
        }

        /*private void button3_Click(object sender, EventArgs e)
        {
            TextBox n = AddNewTextBox();
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into text values('" +n.Visible+ "')",con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("inserted");
        
        }*/
    }

