﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
namespace WindowsFormsApplication1
{
   
    public partial class std : Form
    {
          OleDbConnection oledbConn;
        public std()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
     
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                //OleDbConnection oledbConn;
                string path = openFileDialog1.FileName;
                if (Path.GetExtension(path) == ".xls")
                {
                    oledbConn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=2\"");
                }
                else if (Path.GetExtension(path) == ".xlsx")
                {
                    oledbConn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=YES;IMEX=1;';");
                }

                oledbConn.Open();
                OleDbCommand cmd = new OleDbCommand();
                OleDbDataAdapter oleda = new OleDbDataAdapter();
                DataSet ds = new DataSet();


                cmd.Connection = oledbConn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "SELECT  [rollno], [registerno],[name],[gender], [dateofbirth],[sslc],[hsc], [diploma],[cgpa],[ta], [mobileno],[email],[address] FROM [Sheet1$]";
                oleda = new OleDbDataAdapter(cmd);
                oleda.Fill(ds, "dsSlno");
                dataGridView1.DataSource = ds.Tables["dsSlno"].DefaultView;
                oledbConn.Close();
                textBox1.Text = path;
            }
        }
       

        private void std_Load(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;
            loadcombo();
            loadseccombo();
            
        }
        private void loadseccombo()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select section_id as Code,section as Name from section_master";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud");

            comboBox2.DataSource = Sds.Tables[0];
            //comboBox1.DataSource = Sds.Tables[0];
            comboBox2.DisplayMember = Sds.Tables[0].Columns["Name"].ToString();
            comboBox2.ValueMember = Sds.Tables[0].Columns["Code"].ToString();
            //dataGridView1.DataSource = Sds.Tables["stud"];

        }
        private void loadcombo()
        {

            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select Dept_id as Code,Dept_name as Name from dept_master";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud1");

            comboBox1.DataSource = Sds.Tables[0];
            comboBox1.DisplayMember = Sds.Tables[0].Columns["Name"].ToString();
            comboBox1.ValueMember = Sds.Tables[0].Columns["Code"].ToString();
           
            //dataGridView1.DataSource = Sds.Tables["stud"];

        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

            con.Open();
            
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                string query;
               

                    query = @"insert into std_import([rollno],[registerno],[name],[gender],[dateofbirth],[sslc],[hsc],[diploma],[cgpa],[ta],[mobileno],[email],[address]) values('" + dataGridView1.Rows[i].Cells["rollno"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["registerno"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["name"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["gender"].Value.ToString() + "','" + Convert.ToDateTime(dataGridView1.Rows[i].Cells["dateofbirth"].Value.ToString()) + "','" + dataGridView1.Rows[i].Cells["sslc"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["hsc"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["diploma"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["cgpa"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["ta"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["mobileno"].Value.ToString() + "','" + dataGridView1.Rows[i].Cells["email"].Value.ToString().Trim() + "','" + dataGridView1.Rows[i].Cells["address"].Value.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                }
                

            
            //MessageBox.Show("Records added successfully");
            }
        
        catch
                {
                    MessageBox.Show("multiple entries are not allowed...!");
                }
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
             SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                con.Open();
                String str = "update std_import set [dept_name]='" +comboBox1.Text + "',[section]='" +comboBox2.Text+ "',[year]='" + textBox2.Text + "'";
                SqlCommand scmd = new SqlCommand(str, con);
                scmd.ExecuteNonQuery();
                
            }
            MessageBox.Show("Records added Successfully..!");
    }
    
    
        private void button4_Click(object sender, EventArgs e)
        {
            //con.Open();
            SqlCommand cmd = new SqlCommand("delete from std_import", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("records deleted successfully");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from std_import", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        
    }
}
