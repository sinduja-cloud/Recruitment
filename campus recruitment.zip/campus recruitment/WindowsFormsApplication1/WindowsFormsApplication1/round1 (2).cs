﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class round1 : Form
    {
        String s;
        public round1()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
            if (dataGridView1.Columns[e.ColumnIndex].Name == "checkbox")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                DataGridViewCheckBoxCell cellselect = row.Cells["checkbox"] as DataGridViewCheckBoxCell;
                if (cellselect.Selected)
                {
                 
                    s = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
                    fun();
                }
            }
        }
        private void fun()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
               textBox1.Text = s;
               String st = "UPDATE std_round_details SET round1='" + comboBox1.SelectedItem + "' WHERE registerno=" + textBox1.Text + ""; 
              SqlCommand cmd = new SqlCommand(st,con);
              cmd.ExecuteNonQuery();

        
        }

        private void round1_Load(object sender, EventArgs e)
        {
            show_class_detail();
            dataGridView1.AllowUserToAddRows = false;
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String st1 = "UPDATE std_round_details SET round1='rejected' where [company name]='"+extract_elligible.compname+"'";
            SqlCommand scmd = new SqlCommand(st1, con);
            scmd.ExecuteNonQuery();
            
        }
        private void show_class_detail()
        {
            String str = extract_elligible.com;
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String s = "select registerno as std_regno,name as std_name from std_round_details where [company name]='"+str+"'";
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "ro1");
            dataGridView1.DataSource = sds.Tables["ro1"];


        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "checkbox")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                DataGridViewCheckBoxCell cellselect = row.Cells["checkbox"] as DataGridViewCheckBoxCell;
                if (cellselect.Selected)
                    
                {

                    textBox1.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
                   
                    
                }
            }
        }
        

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String s = "";
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                try
                {

                    if (dataGridView1.Rows[i].Cells["checkbox"].Value.ToString() == "True")
                    {
                        s = dataGridView1.Rows[i].Cells[1].Value.ToString();
                        ComboBox c = extract_elligible.combo;
                        String st = "UPDATE std_round_details SET round1='" + comboBox1.SelectedItem + "' WHERE registerno='" + s + "' and [company name]='" + c.Text + "'"; 
                        SqlCommand Scmd = new SqlCommand(st, con);
                        Scmd.ExecuteNonQuery();


                    }

                    
                }
                catch
                {

                }
                
            }
            MessageBox.Show("Your data is Updated..!");
            }
    }
}
