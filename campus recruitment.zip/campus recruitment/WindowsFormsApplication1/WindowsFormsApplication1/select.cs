﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class select : Form
    {
        public select()
        {
            InitializeComponent();
        }



        private void select_Load(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;
            show_class_detail();
            loadcombo();
            loadcombo1();
           // loadcombo2();


        }
        private void show_class_detail()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            int t1, t2,t3,com1;
           
            t1 = extract_elligible.t1;
            t2 = extract_elligible.t2;
            t3 = extract_elligible.t3;
            com1 = extract_elligible.c1;
            String s;
            if (com1 == 0)
            {
                s = "select registerno as std_regno,name as std_name,dept_name,section,year from std_import where sslc>='" + t1 + "' and hsc>='" + t2 + "' and cgpa>='" + t3 + "' and ta=0";
            }
            else
            {
                s = "select registerno as std_regno,name as std_name,dept_name,section,year from std_import where sslc>='" + t1 + "' and hsc>='" + t2 + "' and cgpa>='" + t3 + "'";
            }
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "ell");
            dataGridView1.DataSource = sds.Tables["ell"];
        }

        private void loadcombo()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select Dept_name from dept_master";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "std0");
            comboBox1.DataSource = sds.Tables["std0"];
            comboBox1.DisplayMember = sds.Tables[0].Columns["Dept_name"].ToString();
        }
        private void loadcombo1()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select section from section_master";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "std1");
            comboBox2.DataSource = sds.Tables["std1"];
            comboBox2.DisplayMember = sds.Tables[0].Columns["section"].ToString();

        }
        /*private void loadcombo2()
        {

            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select [company name] from comp_details ";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "std2");
            comboBox3.DataSource = sds.Tables["std2"];
            comboBox3.DisplayMember = sds.Tables[0].Columns["company name"].ToString();

        }*/

        // String s = "", s1 = "";



        /* private void fun()
         {
             try
             {
                 SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                 con.Open();
                 textBox1.Text = s;
                 textBox2.Text = s1;
                 //String str = "insert into [std_round_details]([registerno],[name],[dept_name],[year],[section],[company name],[elligible_std])values('" + textBox1.Text + "','" + textBox2.Text + "','" + comboBox1.Text + "','" + textBox3.Text + "','" + comboBox2.Text + "','" + comboBox3.Text + "','" + comboBox4.Text + "')";
                 String str = "insert into [std_round_details]([registerno],[name],[dept_name],[year],[section],[company name])values('" + textBox1.Text + "','" + textBox2.Text + "','" + comboBox1.Text + "','" + textBox3.Text + "','" + comboBox2.Text + "','" + comboBox3.Text + "','" + comboBox4.Text + "')";
                 SqlCommand cmd = new SqlCommand(str, con);
                 cmd.ExecuteNonQuery();
               
             }
             catch
             {
                 MessageBox.Show("Register number Already Selected...!");
             }

         }*/
        

        


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "checkbox")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                DataGridViewCheckBoxCell cellselect = row.Cells["checkbox"] as DataGridViewCheckBoxCell;
                if (cellselect.Selected)
                    
                {

                    textBox1.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
                    textBox2.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[2].Value);
                    comboBox1.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[3].Value);
                    textBox3.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[5].Value);
                    comboBox2.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[4].Value);

                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String s = "select registerno as std_regno,name as std_name from std_import where [dept_name]='" + comboBox1.Text + "' and section='"+comboBox2.Text+"' ";
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "ell");
            dataGridView1.DataSource = sds.Tables["ell"];

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String s = "", s1 = "";

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                try
                {
                    if (dataGridView1.Rows[i].Cells["checkbox"].Value.ToString() == "True")
                    {

                        
                        s = dataGridView1.Rows[i].Cells[1].Value.ToString();
                        s1 = dataGridView1.Rows[i].Cells[2].Value.ToString();
                        ComboBox c = extract_elligible.combo;

                        
                       String str = "select registerno,[company name] from std_round_details where registerno='" + textBox1.Text + "' and [company name]='" + extract_elligible.compname.ToString() + "'";
                        SqlCommand cmd = new SqlCommand(str, con);
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        DataSet sds = new DataSet();
                        sda.Fill(sds, "check");
                        DataTable dt = new DataTable();
                        dt = sds.Tables["check"];
                        
                        
                        if (dt.Rows.Count > 0)
                        {
                        }
                        else
                        {
                            String str1 = "insert into [std_round_details]([registerno],[name],[dept_name],[year],[section],[company name],[elligible_std])values('" + s + "','" + s1 + "','" + comboBox1.Text + "','" + textBox3.Text + "','" + comboBox2.Text + "','" + c.Text + "','" + comboBox4.Text + "')";
                            SqlCommand Scmd = new SqlCommand(str1, con);
                            Scmd.ExecuteNonQuery();
                        }
           
                    }
                }
                

              
                catch
                {
                    
                }


            }
            
           /* for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                //try
                //{
                if(dataGridView1.Rows[i].Cells["checkbox"].Value.ToString()=="true")
                    //if (dataGridView1.Rows[i].Cells["checkbox"].Value.ToString()== "true")
                    {

                        s = dataGridView1.Rows[i].Cells[1].Value.ToString();
                        s1 = dataGridView1.Rows[i].Cells[2].Value.ToString();
                           

                        for (int j = 0; j < extract_elligible.gdv.Rows.Count; j++)
                        {

                        
                            ComboBox c = extract_elligible.combo;
                            
                            
                            if (s == extract_elligible.gdv.Rows[j].Cells[0].Value.ToString())
                            {
                                if (c.Text != extract_elligible.gdv.Rows[j].Cells[5].Value.ToString())
                                {
                                    String str = "insert into [std_round_details]([registerno],[name],[dept_name],[year],[section],[company name],[elligible_std])values('" + s + "','" + s1 + "','" + comboBox1.Text + "','" + textBox3.Text + "','" + comboBox2.Text + "','" + c.Text + "','" + comboBox4.Text + "')";
                                    SqlCommand Scmd = new SqlCommand(str, con);
                                    Scmd.ExecuteNonQuery();
                                }
                                else
                                {
                                    MessageBox.Show("already exist");
                                }
                            }
                            else
                            {
                                String str = "insert into [std_round_details]([registerno],[name],[dept_name],[year],[section],[company name],[elligible_std])values('" + s + "','" + s1 + "','" + comboBox1.Text + "','" + textBox3.Text + "','" + comboBox2.Text + "','" + c.Text + "','" + comboBox4.Text + "')";
                                SqlCommand Scmd = new SqlCommand(str, con);
                                Scmd.ExecuteNonQuery(); 
                            }
                        }
                   }
                            
                }
                catch
                {
                }


            }*/
            
            
            MessageBox.Show("Inserted sucessfully");



            SqlConnection scon = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            scon.Open();
            DataTable dt2=new DataTable();
            String cm = "select * from std_round_details";
            SqlCommand cmd1 = new SqlCommand(cm, scon);
            SqlDataAdapter sdas = new SqlDataAdapter(cmd1);
            sdas.Fill(dt2);
            DataSet ds = new DataSet();
            ds.Tables.Add(dt2);
            ds.WriteXmlSchema("ellxml");
            


        }
    }
}
