﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
   
    public partial class login : Form
    {
        public static string user_name;
        public login()
        {
            InitializeComponent();
        }

        public static void rep()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select [registerno],[name],[dept_name],[company name],[selected_students] from std_round_details";
            SqlCommand cmd = new SqlCommand(str, con);
          
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            DataTable dt = new DataTable();
            dt = ds.Tables[0];
            ds.WriteXmlSchema("report1xml");
            
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "admin" && textBox2.Text == "admin")
            {
                this.Hide();
                login.user_name = textBox1.Text.ToString().Trim();
                home h = new home();
                h.Show();
            }
            else
            {
                String t1 = textBox1.Text;
                String t2 = textBox2.Text;
                SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("select username,password from login where username='" + t1 + "' and password='" + t2 + "'", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds, "log");
                DataTable dt = new DataTable();
                dt = ds.Tables["log"];
                //DataRow dr;
                //dr = ds.Tables[0].Rows[0];
                //if (t1 == dr.ItemArray.GetValue(0).ToString()&&t2==dr.ItemArray.GetValue(1).ToString() )
                if (dt.Rows.Count > 0)
                {
                    this.Hide();
                    reportview rv = new reportview();
                    rv.Show();
                    //login.user_name = textBox1.Text.ToString().Trim();
                    //home h = new home();
                    //h.Show();
                }


                else
                {
                    MessageBox.Show("Invalid user name or password");
                    textBox1.Text = "";
                    textBox2.Text = "";
                }

            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will close down the whole application. Confirm?", "Close Application", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("The application has been closed successfully.", "Application Closed!", MessageBoxButtons.OK);
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                this.Activate();
            }
            //MessageBox.Show("The application has been closed successfully.", "Application Closed!", MessageBoxButtons.OK);
            //Application.Exit();
            
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
