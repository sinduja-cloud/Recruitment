﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class section_master : Form
    {
        public section_master()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void section_master_Load(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;
            show_sec_detail();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con1 = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                string insrt1 = "INSERT INTO [section_master] ([section_id],[section]) VALUES ('" + textBox1.Text.Trim() + "','" + textBox2.Text.Trim() + "')";
                con1.Open();
                SqlCommand Scmd1 = new SqlCommand(insrt1, con1);
                Scmd1.ExecuteNonQuery();



                //Scmd1.ExecuteNonQuery();

                con1.Close();
                show_sec_detail();
                MessageBox.Show("Record inserted sucessfully");
                //textBox.Text = "";
                textBox1.Text = "";
                textBox2.Text = "";
            }
            catch
            {
                MessageBox.Show("Section already exist..!");
            }
        }
        private void show_sec_detail()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
           
            string cSQl = "select section_id,section from section_master";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud");
            dataGridView1.DataSource = Sds.Tables["stud"];

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
        

    }
}
