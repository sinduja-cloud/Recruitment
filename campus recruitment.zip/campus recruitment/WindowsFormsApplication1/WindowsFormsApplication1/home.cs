﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void addCompanyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            company cmp = new company();
            cmp.Show();
        }

        private void studentProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            std_profile pr = new std_profile();
            pr.Show();

        }

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            std st = new std();
            st.Show();
        }

        private void quitAllToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Close();
           
        }

        private void companydetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void deptToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dept_master dp = new dept_master();
            dp.Show();

       }

        private void classToolStripMenuItem_Click(object sender, EventArgs e)
        {
            class_master cm = new class_master();
            cm.Show();
        }

        private void sectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            section_master sm = new section_master();
            sm.Show();
        }

        private void quitAllToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void recruitmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            
            
        }

        private void recruitmentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            recruitment_process rp = new recruitment_process();
            rp.Show();
        }

        private void round1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            round1 r1 = new round1();
            r1.Show();
        }

        
    }
}
