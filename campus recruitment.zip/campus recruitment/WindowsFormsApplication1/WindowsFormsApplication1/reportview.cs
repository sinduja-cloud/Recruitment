﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class reportview : Form
    {
        public static DataSet dselig;
        public reportview()
        {
            InitializeComponent();
        }

        private void reportview_Load(object sender, EventArgs e)
        {
            loadcombo();
            loadcombo2();
        }
        private void loadcombo()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select Dept_name from dept_master";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "std0");
            comboBox2.DataSource = sds.Tables["std0"];
            comboBox2.DisplayMember = sds.Tables[0].Columns["Dept_name"].ToString();
        }
        private void loadcombo2()
        {

            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select [company name] from comp_details ";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "std2");
            comboBox1.DataSource = sds.Tables["std2"];
            comboBox1.DisplayMember = sds.Tables[0].Columns["company name"].ToString();
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select [registerno],[name],[dept_name],[company name],[selected_students] from std_round_details where [company name]='"+comboBox1.Text+"' and dept_name='"+comboBox2.Text+"' and selected_students='selected'";
            SqlCommand cmd = new SqlCommand(str, con);

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            dselig = ds;
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.AllowUserToAddRows = false;
                       // DataTable dt = new DataTable();
            //dt = ds.Tables[0];
            //ds.WriteXmlSchema("comprepxml");
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            report r = new report();
            r.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
