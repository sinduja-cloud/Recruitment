﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class round2 : Form
    {
        String s;
        public round2()
        {
            InitializeComponent();
        }

        private void round2_Load(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false; 
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String st1 = "UPDATE std_round_details SET round2='rejected' where [company name]='" + extract_elligible.compname + "'";
            SqlCommand scmd = new SqlCommand(st1, con);
            scmd.ExecuteNonQuery();
            show_class_detail();
 
        }
        private void show_class_detail()
        {
            String str=extract_elligible.com;
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String s = "select registerno as std_regno,name as std_name from std_round_details where round1='selected' and [company name]='" + str + "'";
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "ro2");
            dataGridView1.DataSource = sds.Tables["ro2"];


        }
        private void fun()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            textBox1.Text = s;
            String st = "UPDATE std_round_details SET round2='" + comboBox1.SelectedItem + "' WHERE registerno=" + textBox1.Text + "";
            SqlCommand cmd = new SqlCommand(st, con);
            cmd.ExecuteNonQuery();


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "checkbox")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                DataGridViewCheckBoxCell cellselect = row.Cells["checkbox"] as DataGridViewCheckBoxCell;
                if (cellselect.Selected)
                {
                    s = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
                    fun();

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String s = "";
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                try
                {

                    if (dataGridView1.Rows[i].Cells["checkbox"].Value.ToString() == "True")
                    {
                        s = dataGridView1.Rows[i].Cells[1].Value.ToString();
                        ComboBox c = extract_elligible.combo;
                        String st = "UPDATE std_round_details SET round2='" + comboBox1.SelectedItem + "' WHERE registerno='" + s + "' and [company name]='" + c.Text + "'";
                        SqlCommand Scmd = new SqlCommand(st, con);
                        Scmd.ExecuteNonQuery();


                    }


                }
                catch
                {

                }

            }
            MessageBox.Show("Your data is Updated..!");
         
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "checkbox")
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                DataGridViewCheckBoxCell cellselect = row.Cells["checkbox"] as DataGridViewCheckBoxCell;
                if (cellselect.Selected)
                    
                {

                    textBox1.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells[1].Value);
                   
                    
                }
            }
        }
        }

    }

