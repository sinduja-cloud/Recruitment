﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class class_master : Form
    {
        public class_master()
        {
            InitializeComponent();
        }
     
    
        private void button1_Click(object sender, EventArgs e)
        {


           // show_class_detail();
            /*try
            {*/

            SqlConnection con1 = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string insrt1 = "INSERT INTO [class_master] ([Dept_id],[class],[section]) VALUES ('" + comboBox1.Text+ "','" + textBox2.Text + "','" + comboBox3.SelectedValue.ToString() + "')";
            con1.Open();
            SqlCommand Scmd1 = new SqlCommand(insrt1, con1);
            Scmd1.ExecuteNonQuery();


            //Scmd1.ExecuteNonQuery();
           
            con1.Close();
            show_class_detail();
            MessageBox.Show("Record inserted sucessfully");

            //textBox.Text = "";
            // textBox1.Text = "";
            textBox2.Text = "";
            /* }
             catch
             {
                 MessageBox.Show("class already exist..!");
             }*/
        }
       


        private void loadseccombo()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select section_id as Code,section as Name from section_master";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud");

            comboBox3.DataSource = Sds.Tables[0];
            //comboBox1.DataSource = Sds.Tables[0];
            comboBox3.DisplayMember = Sds.Tables[0].Columns["Name"].ToString();
            comboBox3.ValueMember = Sds.Tables[0].Columns["Code"].ToString();
            //dataGridView1.DataSource = Sds.Tables["stud"];

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void loadcombo()
        {

            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select Dept_id as Code,Dept_name as Name from dept_master";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud1");

            comboBox1.DataSource = Sds.Tables[0];
            comboBox1.DisplayMember = Sds.Tables[0].Columns["Name"].ToString();
            comboBox1.ValueMember = Sds.Tables[0].Columns["Code"].ToString();
            loadseccombo();
            //dataGridView1.DataSource = Sds.Tables["stud"];

        }



        private void show_class_detail()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select  Dept_name as Dept_name,class,section_master.section as section from class_master,dept_master,section_master where class_master.dept_id=dept_master.Dept_id and class_master.section=section_master.section_id";
            //string s1 = "select Dept_name from dept_master where Dept_id=comboBox1.SelectedValue.ToString()";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud");
            //dataGridView1.DataSource = Sds.Tables["stud"];

        }

        private void class_master_Load_1(object sender, EventArgs e)
        {
            show_class_detail();
            //dataGridView1.AllowUserToAddRows = false;
            //dataGridView1.ReadOnly = true;
            loadcombo();
            
        }



       
    }
}
