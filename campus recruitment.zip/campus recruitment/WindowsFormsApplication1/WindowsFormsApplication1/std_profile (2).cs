﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class std_profile : Form
    {
        public std_profile()
        {
            InitializeComponent();
        }
        public void clr()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            richTextBox1.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
           
        }
        private void std_profile_Load(object sender, EventArgs e)
        {
            loadcombo();
            loadseccombo();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          /* try
            {*/
                SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                con.Open();
                string radio = "";
                if (radioButton1.Checked == true)
                {
                    radio = "male";
                }
                if (radioButton2.Checked == true)
                {
                    radio = "female";
                }

                string query = "insert into std_import values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + radio + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text + "','" + richTextBox1.Text + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + textBox12.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Saved...!");
                clr();
            /*}
             catch
            {
                MessageBox.Show("Student already exist..!");
            }*/
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String s = "delete from std_import where [rollno]='"+textBox1.Text+"'";
            SqlCommand cmd = new SqlCommand(s, con);
            cmd.ExecuteNonQuery();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "";
            if (textBox2.Text != "")
            {
                str = "UPDATE std_import SET [registerno]='" + textBox2.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox3.Text != "")
            {
                str = "UPDATE std_import SET [name]='" + textBox3.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox4.Text != "")
            {
                str = "UPDATE std_import SET [dateofbirth]='" + textBox4.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox5.Text != "")
            {
                str = "UPDATE std_import SET [sslc]='" + textBox5.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox6.Text != "")
            {
                str = "UPDATE std_import SET [hsc]='" + textBox6.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox7.Text != "")
            {
                str = "UPDATE std_import SET [diploma]='" + textBox7.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox8.Text != "")
            {
                str = "UPDATE std_import SET [cgpa]='" + textBox7.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox9.Text != "")
            {
                str = "UPDATE std_import SET [ta]='" + textBox8.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox10.Text != "")
            {
                str = "UPDATE std_import SET [mobileno]='" + textBox9.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox11.Text != "")
            {
                str = "UPDATE std_import SET [email]='" + textBox10.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (richTextBox1.Text!="")
            {
                str = "UPDATE std_import SET [address]='" +richTextBox1.Text+ "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (comboBox1.Text!="")
            {
                str = "UPDATE std_import SET [dept_name]='" + comboBox1.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (comboBox2.Text != "")
            {
                str = "UPDATE std_import SET [section]='" + comboBox2.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }
            if (textBox12.Text != "")
            {
                str = "UPDATE std_import SET [year]='" + textBox11.Text + "' WHERE [rollno]='" + textBox1.Text + "'";
            }


            SqlCommand cmd = new SqlCommand(str, con);
            
            cmd.ExecuteNonQuery();
            MessageBox.Show("updated successfully..!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
           
        
        private void loadcombo()
        {

            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select Dept_id as Code,Dept_name as Name from dept_master";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud1");

            comboBox1.DataSource = Sds.Tables[0];
            comboBox1.DisplayMember = Sds.Tables[0].Columns["Name"].ToString();
            comboBox1.ValueMember = Sds.Tables[0].Columns["Code"].ToString();

            //dataGridView1.DataSource = Sds.Tables["stud"];

        }
        private void loadseccombo()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select section_id as Code,section as Name from section_master";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud");

            comboBox2.DataSource = Sds.Tables[0];
            //comboBox1.DataSource = Sds.Tables[0];
            comboBox2.DisplayMember = Sds.Tables[0].Columns["Name"].ToString();
            comboBox2.ValueMember = Sds.Tables[0].Columns["Code"].ToString();
            //dataGridView1.DataSource = Sds.Tables["stud"];

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

    }
}
