﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class dept_master : Form
    {
        public dept_master()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                con.Open();
                string insrt1 = "INSERT INTO [dept_master] ([Dept_id],[Dept_name]) VALUES ('" + textBox1.Text.Trim() + "','" + textBox2.Text.Trim() + "')";
                SqlCommand Scmd1 = new SqlCommand(insrt1, con);
                Scmd1.ExecuteNonQuery();
                con.Close();
                show_dept_detail();
                MessageBox.Show("Record inserted sucessfully");

                //textBox.Text = "";
                textBox1.Text = "";
                textBox2.Text = "";
  

            }
            catch
            {
                MessageBox.Show("Dept_id already exist..!");
            }
            //Scmd1.ExecuteNonQuery();

                  }
        private void dept_master_Load(object sender, EventArgs e)
        {
            show_dept_detail();
        }
        private void show_dept_detail()
        {
           
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            string cSQl = "select Dept_id,Dept_name from dept_master";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds);
            dataGridView1.DataSource = Sds.Tables[0];

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
