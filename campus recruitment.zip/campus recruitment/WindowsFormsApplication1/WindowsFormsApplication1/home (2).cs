﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void addcompanyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            company c = new company();
            c.Show();
        }

        private void addRecruitmentdetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            recruitment_process rp = new recruitment_process();
            rp.Show();
        }

        private void addstudentdatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            std_profile sp = new std_profile();
            sp.Show();
        }

        private void importstudentdatabaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            std s = new std();
            s.Show();
        }

        private void adddepartmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dept_master dm = new dept_master();
            dm.Show();
        }

        private void addclassmasterToolStripMenuItem_Click(object sender, EventArgs e)
        {

            section_master sm = new section_master();
            sm.Show(); 
        }

        private void addsectionmasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            class_master cm = new class_master();
            cm.Show();
        }

        private void selectElligibleCandidatesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void fromDatabaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void round1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            extract_elligible ee = new extract_elligible();
            ee.Show();
            
        }

        private void round1ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            round1 r1 = new round1();
            r1.Show();
            
        }

        private void round3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            round2 r2 = new round2();
            r2.Show();
            
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            change_password cp = new change_password();
            cp.Show();
        }

        private void logoutToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
            //Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void reportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void selectedStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reportview rp = new reportview();
            rp.Show();
        }

        private void round3ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            round3 r3 = new round3();
            r3.Show();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            login l = new login();
            l.Show();
        }

        private void addNewLoginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            login_form lf = new login_form();
            lf.Show();
        }

        

        
    }
}
