﻿namespace WindowsFormsApplication1
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.adminToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.companydetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addcompanyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addRecruitmentdetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentdetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addstudentdatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importstudentdatabaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collegedetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adddepartmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addclassmasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addsectionmasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectionProcessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectElligibleCandidatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fromDatabaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.round1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.round1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.round3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.selectedStudentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.round3ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewLoginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminToolStripMenuItem,
            this.companydetailsToolStripMenuItem,
            this.studentdetailsToolStripMenuItem,
            this.collegedetailsToolStripMenuItem,
            this.selectionProcessToolStripMenuItem,
            this.reportToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1057, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // adminToolStripMenuItem
            // 
            this.adminToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loginToolStripMenuItem,
            this.changePasswordToolStripMenuItem,
            this.logoutToolStripMenuItem});
            this.adminToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.download__12_;
            this.adminToolStripMenuItem.Name = "adminToolStripMenuItem";
            this.adminToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.adminToolStripMenuItem.Text = "Admin";
            this.adminToolStripMenuItem.Click += new System.EventHandler(this.adminToolStripMenuItem_Click);
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.addNewLoginToolStripMenuItem});
            this.loginToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.download__9_;
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.loginToolStripMenuItem.Text = "Login";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.download__13_;
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.download__11_;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click_1);
            // 
            // companydetailsToolStripMenuItem
            // 
            this.companydetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addcompanyToolStripMenuItem,
            this.addRecruitmentdetailsToolStripMenuItem});
            this.companydetailsToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.download__23_;
            this.companydetailsToolStripMenuItem.Name = "companydetailsToolStripMenuItem";
            this.companydetailsToolStripMenuItem.Size = new System.Drawing.Size(126, 20);
            this.companydetailsToolStripMenuItem.Text = "Company_details";
            // 
            // addcompanyToolStripMenuItem
            // 
            this.addcompanyToolStripMenuItem.Name = "addcompanyToolStripMenuItem";
            this.addcompanyToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addcompanyToolStripMenuItem.Text = "Add_company";
            this.addcompanyToolStripMenuItem.Click += new System.EventHandler(this.addcompanyToolStripMenuItem_Click);
            // 
            // addRecruitmentdetailsToolStripMenuItem
            // 
            this.addRecruitmentdetailsToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.im2;
            this.addRecruitmentdetailsToolStripMenuItem.Name = "addRecruitmentdetailsToolStripMenuItem";
            this.addRecruitmentdetailsToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addRecruitmentdetailsToolStripMenuItem.Text = "Add_Recruitment_details";
            this.addRecruitmentdetailsToolStripMenuItem.Click += new System.EventHandler(this.addRecruitmentdetailsToolStripMenuItem_Click);
            // 
            // studentdetailsToolStripMenuItem
            // 
            this.studentdetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addstudentdatToolStripMenuItem,
            this.importstudentdatabaseToolStripMenuItem});
            this.studentdetailsToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.download__21_;
            this.studentdetailsToolStripMenuItem.Name = "studentdetailsToolStripMenuItem";
            this.studentdetailsToolStripMenuItem.Size = new System.Drawing.Size(115, 20);
            this.studentdetailsToolStripMenuItem.Text = "Student_details";
            // 
            // addstudentdatToolStripMenuItem
            // 
            this.addstudentdatToolStripMenuItem.Name = "addstudentdatToolStripMenuItem";
            this.addstudentdatToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addstudentdatToolStripMenuItem.Text = "Add Student Data";
            this.addstudentdatToolStripMenuItem.Click += new System.EventHandler(this.addstudentdatToolStripMenuItem_Click);
            // 
            // importstudentdatabaseToolStripMenuItem
            // 
            this.importstudentdatabaseToolStripMenuItem.Name = "importstudentdatabaseToolStripMenuItem";
            this.importstudentdatabaseToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.importstudentdatabaseToolStripMenuItem.Text = "Import Student Database";
            this.importstudentdatabaseToolStripMenuItem.Click += new System.EventHandler(this.importstudentdatabaseToolStripMenuItem_Click);
            // 
            // collegedetailsToolStripMenuItem
            // 
            this.collegedetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adddepartmentToolStripMenuItem,
            this.addclassmasterToolStripMenuItem,
            this.addsectionmasterToolStripMenuItem});
            this.collegedetailsToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.download__22_;
            this.collegedetailsToolStripMenuItem.Name = "collegedetailsToolStripMenuItem";
            this.collegedetailsToolStripMenuItem.Size = new System.Drawing.Size(114, 20);
            this.collegedetailsToolStripMenuItem.Text = "College_details";
            // 
            // adddepartmentToolStripMenuItem
            // 
            this.adddepartmentToolStripMenuItem.Name = "adddepartmentToolStripMenuItem";
            this.adddepartmentToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.adddepartmentToolStripMenuItem.Text = "Add_Department";
            this.adddepartmentToolStripMenuItem.Click += new System.EventHandler(this.adddepartmentToolStripMenuItem_Click);
            // 
            // addclassmasterToolStripMenuItem
            // 
            this.addclassmasterToolStripMenuItem.Name = "addclassmasterToolStripMenuItem";
            this.addclassmasterToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.addclassmasterToolStripMenuItem.Text = "Add_Section_master";
            this.addclassmasterToolStripMenuItem.Click += new System.EventHandler(this.addclassmasterToolStripMenuItem_Click);
            // 
            // addsectionmasterToolStripMenuItem
            // 
            this.addsectionmasterToolStripMenuItem.Name = "addsectionmasterToolStripMenuItem";
            this.addsectionmasterToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.addsectionmasterToolStripMenuItem.Text = "Add_Class_master";
            this.addsectionmasterToolStripMenuItem.Click += new System.EventHandler(this.addsectionmasterToolStripMenuItem_Click);
            // 
            // selectionProcessToolStripMenuItem
            // 
            this.selectionProcessToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectElligibleCandidatesToolStripMenuItem});
            this.selectionProcessToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.im1;
            this.selectionProcessToolStripMenuItem.Name = "selectionProcessToolStripMenuItem";
            this.selectionProcessToolStripMenuItem.Size = new System.Drawing.Size(128, 20);
            this.selectionProcessToolStripMenuItem.Text = "Selection_Process";
            // 
            // selectElligibleCandidatesToolStripMenuItem
            // 
            this.selectElligibleCandidatesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fromDatabaseToolStripMenuItem});
            this.selectElligibleCandidatesToolStripMenuItem.Name = "selectElligibleCandidatesToolStripMenuItem";
            this.selectElligibleCandidatesToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.selectElligibleCandidatesToolStripMenuItem.Text = "Select_Elligible_Candidates";
            this.selectElligibleCandidatesToolStripMenuItem.Click += new System.EventHandler(this.selectElligibleCandidatesToolStripMenuItem_Click);
            // 
            // fromDatabaseToolStripMenuItem
            // 
            this.fromDatabaseToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.round1ToolStripMenuItem,
            this.round1ToolStripMenuItem1,
            this.round3ToolStripMenuItem,
            this.round3ToolStripMenuItem1});
            this.fromDatabaseToolStripMenuItem.Name = "fromDatabaseToolStripMenuItem";
            this.fromDatabaseToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.fromDatabaseToolStripMenuItem.Text = "from database";
            this.fromDatabaseToolStripMenuItem.Click += new System.EventHandler(this.fromDatabaseToolStripMenuItem_Click);
            // 
            // round1ToolStripMenuItem
            // 
            this.round1ToolStripMenuItem.Name = "round1ToolStripMenuItem";
            this.round1ToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.round1ToolStripMenuItem.Text = "Attendance";
            this.round1ToolStripMenuItem.Click += new System.EventHandler(this.round1ToolStripMenuItem_Click);
            // 
            // round1ToolStripMenuItem1
            // 
            this.round1ToolStripMenuItem1.Name = "round1ToolStripMenuItem1";
            this.round1ToolStripMenuItem1.Size = new System.Drawing.Size(166, 22);
            this.round1ToolStripMenuItem1.Text = "Round1 Selection";
            this.round1ToolStripMenuItem1.Click += new System.EventHandler(this.round1ToolStripMenuItem1_Click);
            // 
            // round3ToolStripMenuItem
            // 
            this.round3ToolStripMenuItem.Name = "round3ToolStripMenuItem";
            this.round3ToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.round3ToolStripMenuItem.Text = "Round2 Selection";
            this.round3ToolStripMenuItem.Click += new System.EventHandler(this.round3ToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectedStudentsToolStripMenuItem});
            this.reportToolStripMenuItem.Image = global::WindowsFormsApplication1.Properties.Resources.download__15_;
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.reportToolStripMenuItem.Text = "Report";
            this.reportToolStripMenuItem.Click += new System.EventHandler(this.reportToolStripMenuItem_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApplication1.Properties.Resources.download__17_;
            this.pictureBox2.Location = new System.Drawing.Point(505, 261);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(196, 238);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApplication1.Properties.Resources.training_placement_cells;
            this.pictureBox1.Location = new System.Drawing.Point(66, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(979, 316);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // selectedStudentsToolStripMenuItem
            // 
            this.selectedStudentsToolStripMenuItem.Name = "selectedStudentsToolStripMenuItem";
            this.selectedStudentsToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.selectedStudentsToolStripMenuItem.Text = "Selected Students";
            this.selectedStudentsToolStripMenuItem.Click += new System.EventHandler(this.selectedStudentsToolStripMenuItem_Click);
            // 
            // round3ToolStripMenuItem1
            // 
            this.round3ToolStripMenuItem1.Name = "round3ToolStripMenuItem1";
            this.round3ToolStripMenuItem1.Size = new System.Drawing.Size(166, 22);
            this.round3ToolStripMenuItem1.Text = "Round3 Selection";
            this.round3ToolStripMenuItem1.Click += new System.EventHandler(this.round3ToolStripMenuItem1_Click);
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // addNewLoginToolStripMenuItem
            // 
            this.addNewLoginToolStripMenuItem.Name = "addNewLoginToolStripMenuItem";
            this.addNewLoginToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.addNewLoginToolStripMenuItem.Text = "Add_New_Login";
            this.addNewLoginToolStripMenuItem.Click += new System.EventHandler(this.addNewLoginToolStripMenuItem_Click);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1057, 646);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Purple;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "placement recruitment management system";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem adminToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companydetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addcompanyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addRecruitmentdetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentdetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addstudentdatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importstudentdatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collegedetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adddepartmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addclassmasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addsectionmasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectionProcessToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectElligibleCandidatesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fromDatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem round1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem round1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem round3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectedStudentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem round3ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewLoginToolStripMenuItem;
    }
}