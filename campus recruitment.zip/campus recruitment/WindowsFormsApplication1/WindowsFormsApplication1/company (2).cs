﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace WindowsFormsApplication1
{
    public partial class company : Form
    {
      
        public static String text;
        public company()
        {
            InitializeComponent();
        }
      
        public void clr()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            comboBox1.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            richTextBox1.Text = "";
        }
        
           
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void company_Load(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;
        }

        private void button2_Click(object sender, EventArgs e)

        {
           /* try
            {*/
            //SqlConnection con = new SqlConnection();
            //con.ConnectionString = ConfigurationSettings.AppSettings["placement"];
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into comp_details values('" + textBox1.Text + "','" + textBox2.Text + "','" + richTextBox1.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "'," + textBox5.Text + "," + textBox6.Text + ",'" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text +"')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Saved...!");
                clr();
           // }
            /*catch
            {
                MessageBox.Show("Company already exist..!");
            }*/

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            textBox11.Text=dateTimePicker1.Value.ToString("dd/MM/yyyy");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("This will Delete the Record. Confirm?", "Confirm Deletion", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("delete from comp_details where [company id]=" +  textBox1.Text + "", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully deleted...!");
                clr();
            }
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            clr();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str="";
            if (textBox2.Text != "")
            {
                str = "UPDATE comp_details SET [company name]='"+textBox2.Text+"' WHERE [company id]="+textBox1.Text+"";
            }
            if (richTextBox1.Text != "")
            {
                str = "UPDATE comp_details SET address='" + textBox2.Text + "' WHERE [company id]="+textBox1.Text+"";
            }
            if (textBox3.Text != "")
            {
                str = "UPDATE comp_details SET state='" + textBox3.Text + "' WHERE [company id]="+textBox1.Text+"";
            }
            if (comboBox1.Text != "")
            {
                str = "UPDATE comp_details SET country='" + comboBox1.Text + "' WHERE [company id]=" + textBox1.Text + "";
            }
            if (textBox5.Text != "")
            {
                str = "UPDATE comp_details SET [area code]=" + textBox5.Text + " WHERE [company id]="+textBox1.Text+"";
            }
            if (textBox6.Text != "")
            {
                str = "UPDATE comp_details SET phone=" + textBox6.Text + " WHERE [company id]="+textBox1.Text+"";
            }
            if (textBox7.Text != "")
            {
                str = "UPDATE comp_details SET [email id]='" + textBox7.Text + "' WHERE [company id]="+textBox1.Text+"";
            }
            if (textBox9.Text != "")
            {
                str = "UPDATE comp_details SET [post name]='" + textBox9.Text + "' WHERE [company id]="+textBox1.Text+"";
            }
            if (textBox8.Text != "")
            {
                str = "UPDATE comp_details SET [contact person]='" + textBox8.Text + "' WHERE [company id]="+textBox1.Text+"";
            }
            if (textBox10.Text != "")
            {
                str = "UPDATE comp_details SET [no of vaccuncy]=" + textBox10.Text + " WHERE [company id]="+textBox1.Text+"";
            }
            if (textBox11.Text != "")
            {
                str = "UPDATE comp_details SET [date of interview]=" + textBox2.Text + " WHERE [company id]="+textBox1.Text+"";
            }
            //str = "UPDATE comp_details SET [company id]=" + textBox1.Text + ",[company name]='" + textBox2.Text + "',address='" + richTextBox1.Text + "',state='" + textBox3.Text + "',country='" + textBox4.Text + "',[area code]=" + textBox5.Text + ",phone=" + textBox6.Text + ",[email id]='" + textBox7.Text + "',[contact person]='" + textBox8.Text + "',[post name]='" + textBox9.Text + "',[no of vaccuncy]=" + textBox10.Text + ",[date of interview]='" + textBox11.Text + "' WHERE [company id]=" + textBox1.Text + "";
            SqlCommand cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated...!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from comp_details", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource=ds.Tables[0];
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            std s1 = new std();
            s1.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
           
            string id = textBox1.Text;
     
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if(id==(Convert.ToString( dataGridView1.Rows[i].Cells["company id"].Value.ToString())))
                {
                    textBox2.Text = Convert.ToString(dataGridView1.Rows[i].Cells["company name"].Value.ToString());
                    richTextBox1.Text = Convert.ToString(dataGridView1.Rows[i].Cells["address"].Value.ToString());
                    textBox3.Text = Convert.ToString(dataGridView1.Rows[i].Cells["state"].Value.ToString());
                    comboBox1.Text = Convert.ToString(dataGridView1.Rows[i].Cells["country"].Value.ToString());
                    textBox5.Text = Convert.ToString(dataGridView1.Rows[i].Cells["area code"].Value.ToString());
                    textBox6.Text = Convert.ToString(dataGridView1.Rows[i].Cells["phone"].Value.ToString());
                    textBox7.Text = Convert.ToString(dataGridView1.Rows[i].Cells["email id"].Value.ToString());
                    textBox8.Text = Convert.ToString(dataGridView1.Rows[i].Cells["contact person"].Value.ToString());
                    textBox9.Text = Convert.ToString(dataGridView1.Rows[i].Cells["post name"].Value.ToString());
                    textBox10.Text = Convert.ToString(dataGridView1.Rows[i].Cells["no of vaccuncy"].Value.ToString());
                    textBox11.Text = Convert.ToString(dataGridView1.Rows[i].Cells["date of interview"].Value.ToString());

                    
                }
            }
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            text = textBox10.Text;
        }
    }
}
