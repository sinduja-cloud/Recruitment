﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class std_profile : Form
    {
        public std_profile()
        {
            InitializeComponent();
        }
        public void clr()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            radioButton1.Text = "";
            radioButton2.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
           
        }
        private void std_profile_Load(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
                con.Open();
                string radio = "";
                if (radioButton1.Checked == true)
                {
                    radio = "male";
                }
                if (radioButton2.Checked == true)
                {
                    radio = "female";
                }

                string query = "insert into std_import values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + radio + "'," + textBox12.Text + ",'" + textBox4.Text + "'," + textBox5.Text + "," + textBox6.Text + ",'" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "','" + textBox11.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully Saved...!");
                clr();
            }
            catch
            {
                MessageBox.Show("Student already exist..!");
            }
        }
    }
}
