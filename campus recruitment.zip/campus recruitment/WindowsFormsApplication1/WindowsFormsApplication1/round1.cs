﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class round1 : Form
    {
        public round1()
        {
            InitializeComponent();
        }

        private void checkbox_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Short;
            dateTimePicker1.Value = DateTime.Today;

            dateTimePicker2.Format = DateTimePickerFormat.Short;
            dateTimePicker2.Value = DateTime.Today;

            dataGridView1.AllowUserToAddRows = false;

            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            string cSQl = "select 'true' as status,rollno as rollno from std_import";
            con.Open();
            SqlCommand Scmd = new SqlCommand(cSQl, con);
            SqlDataAdapter Sda = new SqlDataAdapter(Scmd);
            DataSet Sds = new DataSet();
            Sda.Fill(Sds, "stud");
            dataGridView1.DataSource = Sds.Tables["stud"];
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
             
            string g;
            for (int i = 0; i <= dataGridView1.RowCount - 1; i++)
            {
                if (Convert.ToString(dataGridView1.Rows[i].Cells["status"].Value) == "true")
                {
                    g = Convert.ToString(dataGridView1.Rows[i].Cells["rollno"].Value);
                    //button1.Enabled = true;
                }
                else
                {
                    g = Convert.ToString(dataGridView1.Rows[i].Cells["rollno"].Value);
                    //button1.Enabled = false;
                }

            }

        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.ColumnIndex == dataGridView1.Columns["Status"].Index)
            //{
            //    dataGridView1.EndEdit();  //Stop editing of cell.
            //if ((bool)dataGridView1.Rows[e.RowIndex].Cells["Status"].Value)
            //{
            textBox1.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells["status"].Value);
            textBox2.Text = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells["rollno"].Value);
            //MessageBox.Show("The Value is Checked", "Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ////}
            //else
            //    MessageBox.Show("The Value is UnChecked", "Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void round1_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select 'false' as status,rollno as rollno from std_import", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
