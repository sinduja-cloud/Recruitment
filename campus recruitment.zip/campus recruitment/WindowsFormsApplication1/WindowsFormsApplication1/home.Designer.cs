﻿namespace WindowsFormsApplication1
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.companydetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCompanyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentdetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recruitmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recruitmentDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.round1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.companydetailsToolStripMenuItem,
            this.studentDetailsToolStripMenuItem,
            this.recruitmentToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(932, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // companydetailsToolStripMenuItem
            // 
            this.companydetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addCompanyToolStripMenuItem,
            this.deptToolStripMenuItem,
            this.classToolStripMenuItem,
            this.sectionToolStripMenuItem});
            this.companydetailsToolStripMenuItem.Name = "companydetailsToolStripMenuItem";
            this.companydetailsToolStripMenuItem.Size = new System.Drawing.Size(110, 20);
            this.companydetailsToolStripMenuItem.Text = "Company_details";
            this.companydetailsToolStripMenuItem.Click += new System.EventHandler(this.companydetailsToolStripMenuItem_Click);
            // 
            // addCompanyToolStripMenuItem
            // 
            this.addCompanyToolStripMenuItem.Name = "addCompanyToolStripMenuItem";
            this.addCompanyToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.addCompanyToolStripMenuItem.Text = "Add_Company";
            this.addCompanyToolStripMenuItem.Click += new System.EventHandler(this.addCompanyToolStripMenuItem_Click);
            // 
            // deptToolStripMenuItem
            // 
            this.deptToolStripMenuItem.Name = "deptToolStripMenuItem";
            this.deptToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.deptToolStripMenuItem.Text = "Department";
            this.deptToolStripMenuItem.Click += new System.EventHandler(this.deptToolStripMenuItem_Click);
            // 
            // classToolStripMenuItem
            // 
            this.classToolStripMenuItem.Name = "classToolStripMenuItem";
            this.classToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.classToolStripMenuItem.Text = "class";
            this.classToolStripMenuItem.Click += new System.EventHandler(this.classToolStripMenuItem_Click);
            // 
            // sectionToolStripMenuItem
            // 
            this.sectionToolStripMenuItem.Name = "sectionToolStripMenuItem";
            this.sectionToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.sectionToolStripMenuItem.Text = "section";
            this.sectionToolStripMenuItem.Click += new System.EventHandler(this.sectionToolStripMenuItem_Click);
            // 
            // studentDetailsToolStripMenuItem
            // 
            this.studentDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudentdetailsToolStripMenuItem,
            this.addStudentToolStripMenuItem});
            this.studentDetailsToolStripMenuItem.Name = "studentDetailsToolStripMenuItem";
            this.studentDetailsToolStripMenuItem.Size = new System.Drawing.Size(100, 20);
            this.studentDetailsToolStripMenuItem.Text = "Student_Details";
            // 
            // addStudentdetailsToolStripMenuItem
            // 
            this.addStudentdetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentProfileToolStripMenuItem});
            this.addStudentdetailsToolStripMenuItem.Name = "addStudentdetailsToolStripMenuItem";
            this.addStudentdetailsToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.addStudentdetailsToolStripMenuItem.Text = "Add_Student_entry";
            // 
            // studentProfileToolStripMenuItem
            // 
            this.studentProfileToolStripMenuItem.Name = "studentProfileToolStripMenuItem";
            this.studentProfileToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.studentProfileToolStripMenuItem.Text = "Student_Profile";
            this.studentProfileToolStripMenuItem.Click += new System.EventHandler(this.studentProfileToolStripMenuItem_Click);
            // 
            // addStudentToolStripMenuItem
            // 
            this.addStudentToolStripMenuItem.Name = "addStudentToolStripMenuItem";
            this.addStudentToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.addStudentToolStripMenuItem.Text = "Import_Student_data";
            this.addStudentToolStripMenuItem.Click += new System.EventHandler(this.addStudentToolStripMenuItem_Click);
            // 
            // recruitmentToolStripMenuItem
            // 
            this.recruitmentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.recruitmentDetailsToolStripMenuItem,
            this.round1ToolStripMenuItem});
            this.recruitmentToolStripMenuItem.Name = "recruitmentToolStripMenuItem";
            this.recruitmentToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.recruitmentToolStripMenuItem.Text = "recruitment";
            this.recruitmentToolStripMenuItem.Click += new System.EventHandler(this.recruitmentToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quitAllToolStripMenuItem});
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "exit";
            // 
            // quitAllToolStripMenuItem
            // 
            this.quitAllToolStripMenuItem.Name = "quitAllToolStripMenuItem";
            this.quitAllToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.quitAllToolStripMenuItem.Text = "quit all";
            this.quitAllToolStripMenuItem.Click += new System.EventHandler(this.quitAllToolStripMenuItem_Click_1);
            // 
            // recruitmentDetailsToolStripMenuItem
            // 
            this.recruitmentDetailsToolStripMenuItem.Name = "recruitmentDetailsToolStripMenuItem";
            this.recruitmentDetailsToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.recruitmentDetailsToolStripMenuItem.Text = "recruitment details";
            this.recruitmentDetailsToolStripMenuItem.Click += new System.EventHandler(this.recruitmentDetailsToolStripMenuItem_Click);
            // 
            // round1ToolStripMenuItem
            // 
            this.round1ToolStripMenuItem.Name = "round1ToolStripMenuItem";
            this.round1ToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.round1ToolStripMenuItem.Text = "round1";
            this.round1ToolStripMenuItem.Click += new System.EventHandler(this.round1ToolStripMenuItem_Click);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.training_placement_cells;
            this.ClientSize = new System.Drawing.Size(932, 330);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Bell MT", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Purple;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "home";
            this.Text = "home";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem companydetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCompanyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentdetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recruitmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recruitmentDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem round1ToolStripMenuItem;
    }
}