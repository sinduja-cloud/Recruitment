﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class report : Form
    {
        public report()
        {
            InitializeComponent();
        }

        private void report_Load(object sender, EventArgs e)
        {
            CrystalReport2 cr = new CrystalReport2();
            // Periodical_report p1 = new Periodical_report();
            DataSet dsrpt = new DataSet();
            //DataTable dtrpt = Form2DataTable.Copy();
            //dsrpt.Tables.Add(dtrpt);
            dsrpt =  reportview.dselig;
            cr.SetDataSource(dsrpt);
            //crystalReportViewer1.ShowGroupTree
            crystalReportViewer1.ReportSource = cr;
            
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
