﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    
    
    public partial class extract_elligible : Form
    {
        public static int t1, t2, t3,c1=1;
        public static String com;
        public static String compname;
       // public static ComboBox com1;
       
        public static DataTable ndt=new DataTable();
        public static DataSet comp = new DataSet();
        public static ComboBox combo;
        public static DataGridView gdv=new DataGridView();
        public extract_elligible()
        {
            InitializeComponent();
            
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            com = comboBox2.Text;
            t1 = Convert.ToInt32(textBox1.Text);
            t2 = Convert.ToInt32(textBox2.Text);
            t3 = Convert.ToInt32(textBox3.Text);
            
            if (comboBox3.Text == "no")
            {
                c1 = 0;
            }


            if (comboBox1.Text == "select any one")
            {
                MessageBox.Show("please choose any one in the combo box...!");
            }
            else if (comboBox1.Text == "Attendance ")
            {
                select s = new select();
                s.Show();
            }
           
            else if (comboBox1.Text == "Round1")
            {
                round1 r1 = new round1();
                r1.Show();
            }
            else if (comboBox1.Text == "Round2")
            {
                round2 r2 = new round2();
                r2.Show();
            }
            else if (comboBox1.Text == "Round3")
            {
                round3 r3 = new round3();
                r3.Show();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String quer = "select * from std_round_details";
            SqlCommand cmd = new SqlCommand(quer, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds);
            dataGridView1.DataSource = sds.Tables[0];
            
        }

        private void extract_elligible_Load(object sender, EventArgs e)
        {
            compname = comboBox2.Text;
            dataGridView1.AllowUserToAddRows = false;
            loadcombo2();
           
            
        }
        private void loadcombo2()
        {
           
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select [company name] from comp_details ";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet sds = new DataSet();
            sda.Fill(sds, "std2");
            comboBox2.DataSource = sds.Tables["std2"];
            comboBox2.DisplayMember = sds.Tables[0].Columns["company name"].ToString();
            comp = sds;
            combo = comboBox2;

        }



        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            gdv = dataGridView1;
      
        }
        public void fun()
        {
            SqlConnection con = new SqlConnection("Data Source=NRINFOTECH-PC;Initial Catalog=placement;Integrated Security=True");
            con.Open();
            String str = "select * from std_round_details";
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sd.Fill(ds);
            DataTable dt = new DataTable();
            dt = ds.Tables["result"];
            ndt = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            login.rep();
            report rp = new report();
            rp.Show();

        }
    }
}
